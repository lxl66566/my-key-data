// ==UserScript==
// @name        Make Bilibili Great Than Ever Before
// @description A fork of @kookxiang's userscript "Make Bilibili Great Again", but with many experimental features
// @namespace   https://skk.moe
// @run-at      document-start
// @match       https://www.bilibili.com/*
// @match       https://t.bilibili.com/*
// @match       https://live.bilibili.com/*
// @updateURL   https://unpkg.com/make-bilibili-great-than-ever-before@latest/dist/make-bilibili-great-than-ever-before.meta.js
// @downloadURL https://unpkg.com/make-bilibili-great-than-ever-before@latest/dist/make-bilibili-great-than-ever-before.user.js
// @version     1.1.4
// @author      SukkaW <https://skk.moe>
// @grant       unsafeWindow
// @grant       GM.notification
// ==/UserScript==

(function(){'use strict';const o=()=>{},r=()=>!0;/* eslint-disable no-restricted-globals -- logger */ /* eslint-disable no-console -- logger */ const logger = {
    log (...args) {
        console.log('[make-bilibili-great-than-ever-before]', ...args);
    },
    error (...args) {
        console.error('[make-bilibili-great-than-ever-before]', ...args);
    },
    warn (...args) {
        console.warn('[make-bilibili-great-than-ever-before]', ...args);
    },
    info (...args) {
        console.info('[make-bilibili-great-than-ever-before]', ...args);
    },
    debug (...args) {
        console.debug('[make-bilibili-great-than-ever-before]', ...args);
    },
    trace (...args) {
        console.trace('[make-bilibili-great-than-ever-before]', ...args);
    }
};function getUrlFromRequest(request) {
    if (typeof request === 'string') {
        return request;
    }
    if ('href' in request) {
        return request.href;
    }
    if ('url' in request) {
        return request.url;
    }
    logger.error('Invalid requestInfo', request);
    return null;
}function createMockClass(className, instanceMethods = {}, staticMethods = {}) {
    const fakeClassInstance = new Proxy(o, {
        get (target, prop) {
            if (prop in instanceMethods) {
                return instanceMethods[prop];
            }
            return (...args)=>{
                logger.log(`(new ${className})[${String(prop)}] called with arguments:`, args);
            };
        }
    });
    return new Proxy(class {
    }, {
        construct () {
            return fakeClassInstance;
        },
        get (target, prop) {
            if (prop in staticMethods) {
                return staticMethods[prop];
            }
            return (...args)=>{
                logger.log(`window.${className}[${String(prop)}] called with arguments:`, args);
            };
        }
    });
}function defineReadonlyProperty(target, key, value, enumerable = true) {
    Object.defineProperty(target, key, {
        get () {
            return value;
        },
        set: o,
        configurable: false,
        enumerable
    });
}const defuseSpyware = {
    name: 'defuse-spyware',
    description: '禁用叔叔日志上报和用户跟踪的无限请求风暴',
    any ({ onBeforeFetch, onXhrOpen }) {
        defineReadonlyProperty(unsafeWindow.navigator, 'sendBeacon', r);
        const SentryHub = createMockClass('SentryHub');
        const fakeSentry = {
            SDK_NAME: 'sentry.javascript.browser',
            SDK_VERSION: '0.0.1145141919810',
            BrowserClient: createMockClass('Sentry.BrowserClient'),
            Hub: SentryHub,
            Integrations: {
                Vue: createMockClass('Sentry.Integrations.Vue'),
                GlobalHandlers: createMockClass('Sentry.Integrations.GlobalHandlers'),
                InboundFilters: createMockClass('Sentry.Integrations.InboundFilters')
            },
            init: o,
            configureScope: o,
            getCurrentHub: ()=>new SentryHub(),
            setContext: o,
            setExtra: o,
            setExtras: o,
            setTag: o,
            setTags: o,
            setUser: o,
            wrap: o
        };
        defineReadonlyProperty(unsafeWindow, 'Sentry', fakeSentry);
        defineReadonlyProperty(unsafeWindow, 'MReporter', createMockClass('MReporter'));
        defineReadonlyProperty(unsafeWindow, 'ReporterPb', createMockClass('ReporterPb'));
        defineReadonlyProperty(unsafeWindow, '__biliUserFp__', {
            init: o,
            queryUserLog () {
                return [];
            }
        });
        defineReadonlyProperty(unsafeWindow, '__USER_FP_CONFIG__', undefined);
        defineReadonlyProperty(unsafeWindow, '__MIRROR_CONFIG__', undefined);
        onBeforeFetch((fetchArgs)=>{
            const url = getUrlFromRequest(fetchArgs[0]);
            if (typeof url === 'string' && url.includes('data.bilibili.com')) {
                return new Response();
            }
            return fetchArgs;
        });
        onXhrOpen((args)=>{
            let url = args[1];
            if (typeof url !== 'string') {
                url = url.href;
            }
            if (url.includes('data.bilibili.com')) {
                return null;
            }
            if (url.includes('api.bilibili.com/x/internal/gaia-gateway/ExClimbWuzhi')) {
                return null;
            }
            return args;
        });
    }
};class ListNode {
    timestamp;
    next;
    prev;
    constructor(timestamp){
        this.timestamp = timestamp;
        this.next = null;
        this.prev = null;
    }
}
class ErrorCounter {
    timeWindow;
    head;
    tail;
    intervalId;
    $size;
    constructor(timeWindow = 10000){
        this.timeWindow = timeWindow;
        this.head = null;
        this.tail = null;
        this.$size = 0;
        this.intervalId = self.setInterval(()=>this.cleanup(), 1000);
    }
    recordError() {
        const now = Date.now();
        const newNode = new ListNode(now);
        if (this.tail) {
            this.tail.next = newNode;
            newNode.prev = this.tail;
            this.tail = newNode;
        } else {
            this.head = newNode;
            this.tail = newNode;
        }
        this.$size++;
    }
    getErrorCount() {
        this.cleanup();
        return this.$size;
    // let count = 0;
    // let current = this.head;
    // while (current) {
    //   count++;
    //   current = current.next;
    // }
    // return count;
    }
    cleanup() {
        const now = Date.now();
        while(this.head && now - this.head.timestamp > this.timeWindow){
            this.head = this.head.next;
            if (this.head) {
                this.head.prev = null;
            } else {
                this.tail = null;
            }
            this.$size--;
        }
    }
    stop() {
        clearInterval(this.intervalId);
    }
}function e(r,...t){return r.reduce((e,r,n)=>e+r+(t[n]??""),"")}// const mcdnRegexp = /[\dxy]+\.mcdn\.bilivideo\.cn:\d+/;
const qualityRegexp = /(live-bvc\/\d+\/live_\d+_\d+)_\w+/;
const enhanceLive = {
    name: 'enhance-live',
    description: '增强直播（原画画质、其他修复）',
    onLive ({ addStyle, onBeforeFetch, onResponse }) {
        let forceHighestQuality = true;
        // 还得帮叔叔修 bug，唉
        addStyle(e`div[data-cy=EvaRenderer_LayerWrapper]:has(.player) { z-index: 999999; }`);
        // 干掉些直播间没用的东西
        addStyle(e`#welcome-area-bottom-vm, .web-player-icon-roomStatus { display: none !important; }`);
        // 修复直播画质
        onBeforeFetch((fetchArgs)=>{
            if (!forceHighestQuality) {
                return fetchArgs;
            }
            try {
                const url = getUrlFromRequest(fetchArgs[0]);
                if (url == null) {
                    return fetchArgs;
                }
                // if (mcdnRegexp.test(url) && disableMcdn) {
                //   return Promise.reject();
                // }
                if (qualityRegexp.test(url)) {
                    const newUrl = url.replace(qualityRegexp, '$1').replaceAll(/(\d+)_(?:mini|pro)hevc/g, '$1');
                    logger.info('force quality', url, '->', newUrl);
                    fetchArgs[0] = newUrl;
                }
                return fetchArgs;
            } catch  {
                return fetchArgs;
            }
        });
        const errorCounter = new ErrorCounter(1000 * 30);
        onResponse((response)=>{
            if (response.url.includes('.m3u8') || response.url.includes('.m4s')) {
                if (!response.ok) {
                    errorCounter.recordError();
                }
                if (forceHighestQuality && errorCounter.getErrorCount() >= 5) {
                    forceHighestQuality = false;
                    GM.notification('[Make Bilibili Great Then Ever Before] 已为您自动切换至播放器上选择的清晰度.', '最高清晰度可能不可用');
                }
            }
            return response;
        });
    }
};const fixCopyInCV = {
    name: 'fix-copy-in-cv',
    description: '修复文章复制功能',
    onCV () {
        if ('original' in unsafeWindow) {
            defineReadonlyProperty(unsafeWindow.original, 'reprint', '1');
        }
        const holder = document.querySelector('.article-holder');
        if (holder) {
            holder.classList.remove('unable-reprint');
            holder.addEventListener('copy', (e)=>e.stopImmediatePropagation(), true);
        }
    }
};const noAd = {
    name: 'no-ad',
    description: '防止叔叔通过广告给自己赚棺材钱',
    any ({ addStyle }) {
        // 去广告
        /**
     * 下面是叔叔家的垃圾前端在 computed 里写副作用检测 AdBlock 是否启用：

    u = () => {
      var A;
      if (!h.value)
        return !1;
      const _ = "cm."
        , v = "bilibili.com"
        , f = ((A = h.value) == null ? void 0 : A.querySelectorAll(`a[href*="${_}${v}"]`)) || [];
      for (let y = 0; y < f.length; y++)
        if (window.getComputedStyle(f[y]).display == "none")
          return !0;
      return !1

      我们只要 display 不是 none 就行了
    }
     */ addStyle(e`
      a[href*="cm.bilibili.com"],
      .desktop-download-tip,
      .ad-report {
        width: 1px !important;
        height: 1px !important;
        opacity: 0 !important;
        pointer-events: none !important;
        position: absolute !important;
        padding: 0 !important;
        margin: -1px !important;
        overflow: hidden !important;
        clip: rect(0, 0, 0, 0) !important;
        white-space: nowrap !important;
        border-width: 0 !important;
      }
    `);
        if (unsafeWindow.__INITIAL_STATE__?.adData) {
            for(const key in unsafeWindow.__INITIAL_STATE__.adData){
                if (!Array.isArray(unsafeWindow.__INITIAL_STATE__.adData[key])) continue;
                for (const item of unsafeWindow.__INITIAL_STATE__.adData[key]){
                    item.name = 'B 站未来有可能会倒闭，但绝不会变质';
                    item.pic = 'https://static.hdslb.com/images/transparent.gif';
                    item.url = 'https://space.bilibili.com/208259';
                }
            }
        }
        if (unsafeWindow.__INITIAL_STATE__?.elecFullInfo) {
            unsafeWindow.__INITIAL_STATE__.elecFullInfo.list = [];
        }
    }
};const rBackupCdn = /(?:up|cn-)[\w-]+\.bilivideo\.com/g;
let prevLocationHref = '';
let prevCdnDomains = [];
function getCDNDomain() {
    if (prevLocationHref !== unsafeWindow.location.href || prevCdnDomains.length === 0) {
        try {
            const matched = Array.from(new Set(Array.from(document.head.innerHTML.matchAll(rBackupCdn), (match)=>match[0])));
            if (matched.length > 0) {
                prevLocationHref = unsafeWindow.location.href;
                prevCdnDomains = matched;
            } else {
                logger.warn('Failed to get CDN domains from document.head.innerHTML, fallback to default CDN domain');
                prevLocationHref = unsafeWindow.location.href;
                prevCdnDomains = [
                    'upos-sz-mirrorcoso1.bilivideo.com'
                ];
                return 'upos-sz-mirrorcoso1.bilivideo.com';
            }
        } catch (e) {
            logger.error('Failed to get CDN domains from document.head.innerHTML, fallback to default CDN domain', e);
            prevLocationHref = unsafeWindow.location.href;
            prevCdnDomains = [
                'upos-sz-mirrorcoso1.bilivideo.com'
            ];
            return 'upos-sz-mirrorcoso1.bilivideo.com';
        }
    }
    return prevCdnDomains.length === 1 ? prevCdnDomains[0] : prevCdnDomains[Math.floor(Math.random() * prevCdnDomains.length)];
}
const noP2P = {
    name: 'no-p2p',
    description: '防止叔叔用 P2P CDN 省下纸钱',
    any ({ onXhrOpen, onBeforeFetch }) {
        class MockPCDNLoader {
        }
        class MockBPP2PSDK {
            on = o;
        }
        class MockSeederSDK {
        }
        defineReadonlyProperty(unsafeWindow, 'PCDNLoader', MockPCDNLoader);
        defineReadonlyProperty(unsafeWindow, 'BPP2PSDK', MockBPP2PSDK);
        defineReadonlyProperty(unsafeWindow, 'SeederSDK', MockSeederSDK);
        // Patch new Native Player
        (function(HTMLMediaElementPrototypeSrcDescriptor) {
            Object.defineProperty(unsafeWindow.HTMLMediaElement.prototype, 'src', {
                ...HTMLMediaElementPrototypeSrcDescriptor,
                set (value) {
                    if (typeof value !== 'string') {
                        value = String(value);
                    }
                    try {
                        const result = replaceP2P(value, getCDNDomain(), 'HTMLMediaElement.prototype.src');
                        value = typeof result === 'string' ? result : result.href;
                    } catch (e) {
                        logger.error('Failed to handle HTMLMediaElement.prototype.src setter', e, {
                            value
                        });
                    }
                    HTMLMediaElementPrototypeSrcDescriptor?.set?.call(this, value);
                }
            });
        })(Object.getOwnPropertyDescriptor(unsafeWindow.HTMLMediaElement.prototype, 'src'));
        onXhrOpen((xhrOpenArgs)=>{
            try {
                xhrOpenArgs[1] = replaceP2P(xhrOpenArgs[1], getCDNDomain(), 'XMLHttpRequest.prototype.open');
            } catch (e) {
                logger.error('Failed to replace P2P for XMLHttpRequest.prototype.open', e, {
                    xhrUrl: xhrOpenArgs[1]
                });
            }
            return xhrOpenArgs;
        });
        onBeforeFetch((fetchArgs)=>{
            let input = fetchArgs[0];
            if (typeof input === 'string' || 'href' in input) {
                input = replaceP2P(input, getCDNDomain(), 'fetch');
            } else if ('url' in input) {
                input = new Request(replaceP2P(input.url, getCDNDomain(), 'fetch'), input);
            } else ;
            fetchArgs[0] = input;
            return fetchArgs;
        });
    }
};
function replaceP2P(url, cdnDomain, meta = '') {
    try {
        if (typeof url === 'string') {
            // early bailout for better performance
            if (!url.includes('.mcdn.bilivideo.cn') && !url.includes('.szbdyd.com')) {
                return url;
            }
            if (url.startsWith('//')) {
                url = unsafeWindow.location.protocol + url;
            }
            url = new URL(url, unsafeWindow.location.href);
        }
        const hostname = url.hostname;
        if (hostname.endsWith('.mcdn.bilivideo.cn')) {
            url.hostname = cdnDomain;
            url.port = '443';
            logger.info(`P2P replaced: ${hostname} -> ${cdnDomain}`, {
                meta
            });
        } else if (hostname.endsWith('.szbdyd.com')) {
            const xy_usource = url.searchParams.get('xy_usource');
            if (xy_usource) {
                url.hostname = xy_usource;
                url.port = '443';
                logger.info(`P2P replaced: ${hostname} -> ${xy_usource}`, {
                    meta
                });
            }
        }
        return url;
    } catch (e) {
        logger.error(`Failed to replace P2P for URL (${url}):`, e);
        return url;
    }
}const noopNeverResolvedPromise = ()=>new Promise(o);
// based on uBlock Origin's no-webrtc
// https://github.com/gorhill/uBlock/blob/6c228a8bfdcfc14140cdd3967270df28598c1aaf/src/js/resources/scriptlets.js#L2216
const noWebRTC = {
    name: 'no-webrtc',
    description: '通过禁用 WebRTC 防止叔叔省下棺材钱',
    any () {
        const rtcPcNames = [];
        if ('RTCPeerConnection' in unsafeWindow) {
            rtcPcNames.push('RTCPeerConnection');
        }
        if ('webkitRTCPeerConnection' in unsafeWindow) {
            rtcPcNames.push('webkitRTCPeerConnection');
        }
        if ('mozRTCPeerConnection' in unsafeWindow) {
            rtcPcNames.push('mozRTCPeerConnection');
        }
        const rtcDcNames = [];
        if ('RTCDataChannel' in unsafeWindow) {
            rtcDcNames.push('RTCDataChannel');
        }
        if ('webkitRTCDataChannel' in unsafeWindow) {
            rtcDcNames.push('webkitRTCDataChannel');
        }
        if ('mozRTCDataChannel' in unsafeWindow) {
            rtcDcNames.push('mozRTCDataChannel');
        }
        class MockDataChannel {
            static{
                this.prototype.close = o;
                this.prototype.send = o;
                this.prototype.addEventListener = o;
                this.prototype.removeEventListener = o;
                this.prototype.onbufferedamountlow = o;
                // eslint-disable-next-line sukka/unicorn/prefer-add-event-listener -- mock
                this.prototype.onclose = o;
                // eslint-disable-next-line sukka/unicorn/prefer-add-event-listener -- mock
                this.prototype.onerror = o;
                // eslint-disable-next-line sukka/unicorn/prefer-add-event-listener -- mock
                this.prototype.onmessage = o;
            }
            // eslint-disable-next-line @typescript-eslint/class-methods-use-this -- toString
            toString() {
                return '[object RTCDataChannel]';
            }
        }
        class MockRTCSessionDescription {
            type;
            sdp;
            constructor(init){
                this.type = init.type;
                this.sdp = init.sdp || '';
            }
            toJSON() {
                return {
                    type: this.type,
                    sdp: this.sdp
                };
            }
        }
        const mockedRtcSessionDescription = new MockRTCSessionDescription({
            type: 'offer',
            sdp: ''
        });
        class MockRTCPeerConnection {
            // eslint-disable-next-line @typescript-eslint/class-methods-use-this -- mock
            createDataChannel() {
                return new MockDataChannel();
            }
            static{
                this.prototype.close = o;
                this.prototype.createOffer = noopNeverResolvedPromise;
                this.prototype.setLocalDescription = o;
                this.prototype.setRemoteDescription = o;
                this.prototype.addEventListener = o;
                this.prototype.removeEventListener = o;
                this.prototype.addIceCandidate = o;
                this.prototype.setConfiguration = o;
                this.prototype.localDescription = mockedRtcSessionDescription;
                this.prototype.createAnswer = noopNeverResolvedPromise;
                this.prototype.onicecandidate = o;
            }
            // eslint-disable-next-line @typescript-eslint/class-methods-use-this -- mock
            toString() {
                return '[object RTCPeerConnection]';
            }
        }
        for (const rtc of rtcPcNames){
            defineReadonlyProperty(unsafeWindow, rtc, MockRTCPeerConnection);
        }
        for (const dc of rtcDcNames){
            defineReadonlyProperty(unsafeWindow, dc, MockDataChannel);
        }
        defineReadonlyProperty(unsafeWindow, 'RTCSessionDescription', MockRTCSessionDescription);
    }
};const optimizeHomepage = {
    name: 'optimize-homepage',
    description: '首页广告去除和样式优化',
    any ({ addStyle }) {
        addStyle(e`
      .feed2 .feed-card:has(a[href*="cm.bilibili.com"]),
      .feed2 .feed-card:has(.bili-video-card:empty) {
        width: 1px !important;
        height: 1px !important;
        opacity: 0 !important;
        pointer-events: none !important;
        position: absolute !important;
        padding: 0 !important;
        margin: -1px !important;
        overflow: hidden !important;
        clip: rect(0, 0, 0, 0) !important;
        white-space: nowrap !important;
        border-width: 0 !important;
      }

      .feed2 .container > * {
        margin-top: 0 !important
      }
    `);
    }
};function onDOMContentLoaded(callback) {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', callback, {
            once: true
        });
    } else {
        callback();
    }
}
function onLoaded(callback) {
    if (document.readyState === 'complete') {
        callback();
    } else {
        // eslint-disable-next-line no-restricted-globals -- use sandboxed event handler
        window.addEventListener('load', callback, {
            once: true
        });
    }
}const optimizeStory = {
    name: 'optimize-story',
    description: '动态页面优化',
    onStory ({ addStyle }) {
        addStyle(e`
      html[wide] #app { display: flex; }
      html[wide] .bili-dyn-home--member { box-sizing: border-box;padding: 0 10px;width: 100%;flex: 1; }
      html[wide] .bili-dyn-content { width: initial; }
      html[wide] main { margin: 0 8px;flex: 1;overflow: hidden;width: initial; }
      #wide-mode-switch { margin-left: 0;margin-right: 20px; }
      .bili-dyn-list__item:has(.bili-dyn-card-goods), .bili-dyn-list__item:has(.bili-rich-text-module.goods) { display: none !important }
    `);
        if (!localStorage.WIDE_OPT_OUT) {
            document.documentElement.setAttribute('wide', 'wide');
        }
        onLoaded(()=>{
            const tabContainer = document.querySelector('.bili-dyn-list-tabs__list');
            const placeHolder = document.createElement('div');
            placeHolder.style.flex = '1';
            const switchButton = document.createElement('a');
            switchButton.id = 'wide-mode-switch';
            switchButton.className = 'bili-dyn-list-tabs__item';
            switchButton.textContent = '宽屏模式';
            switchButton.addEventListener('click', (e)=>{
                e.preventDefault();
                if (localStorage.WIDE_OPT_OUT) {
                    localStorage.removeItem('WIDE_OPT_OUT');
                    document.documentElement.setAttribute('wide', 'wide');
                } else {
                    localStorage.setItem('WIDE_OPT_OUT', '1');
                    document.documentElement.removeAttribute('wide');
                }
            });
            tabContainer?.appendChild(placeHolder);
            tabContainer?.appendChild(switchButton);
        });
    }
};function toggleMode(enabled) {
    if (enabled) {
        document.body.setAttribute('video-fit', '');
    } else {
        document.body.removeAttribute('video-fit');
    }
}
const playerVideoFit = {
    name: 'player-video-fit',
    description: '播放器视频裁切模式',
    onVideo ({ addStyle }) {
        addStyle(e`body[video-fit] #bilibili-player video { object-fit: cover; } .bpx-player-ctrl-setting-fit-mode { display: flex;width: 100%;height: 32px;line-height: 32px; } .bpx-player-ctrl-setting-box .bui-panel-wrap, .bpx-player-ctrl-setting-box .bui-panel-item { min-height: 172px !important; }`);
        let timer;
        function injectButton() {
            if (!document.querySelector('.bpx-player-ctrl-setting-menu-left')) {
                return;
            }
            self.clearInterval(timer);
            const parent = document.querySelector('.bpx-player-ctrl-setting-menu-left');
            const item = document.createElement('div');
            item.className = 'bpx-player-ctrl-setting-fit-mode bui bui-switch';
            item.innerHTML = '<input class="bui-switch-input" type="checkbox"><label class="bui-switch-label"><span class="bui-switch-name">裁切模式</span><span class="bui-switch-body"><span class="bui-switch-dot"><span></span></span></span></label>';
            parent?.insertBefore(item, document.querySelector('.bpx-player-ctrl-setting-more'));
            document.querySelector('.bpx-player-ctrl-setting-fit-mode input')?.addEventListener('change', (e)=>toggleMode(e.target.checked));
            const panelItem = document.querySelector('.bpx-player-ctrl-setting-box .bui-panel-item');
            if (panelItem) {
                panelItem.style.height = '';
            }
        }
        timer = self.setInterval(injectButton, 200);
    }
};const removeBlackBackdropFilter = {
    name: 'remove-black-backdrop-filter',
    description: '去除叔叔去世时的全站黑白效果',
    any ({ addStyle }) {
        addStyle(e`html, body { -webkit-filter: none !important; filter: none !important; }`);
    }
};const uselessUrlParams = [
    'buvid',
    'is_story_h5',
    'launch_id',
    'live_from',
    'mid',
    'session_id',
    'timestamp',
    'up_id',
    'vd_source',
    /^share/,
    /^spm/
];
const removeUselessUrlParams = {
    name: 'remove-useless-url-params',
    description: '清理 URL 中的无用参数',
    any () {
        unsafeWindow.history.replaceState(undefined, '', removeTracking(location.href));
        // eslint-disable-next-line @typescript-eslint/unbound-method -- called with Reflect.apply
        const pushState = unsafeWindow.history.pushState;
        unsafeWindow.history.pushState = function(state, unused, url) {
            return Reflect.apply(pushState, this, [
                state,
                unused,
                removeTracking(url)
            ]);
        };
        // eslint-disable-next-line @typescript-eslint/unbound-method -- called with Reflect.apply
        const replaceState = unsafeWindow.history.replaceState;
        unsafeWindow.history.replaceState = function(state, unused, url) {
            return Reflect.apply(replaceState, this, [
                state,
                unused,
                removeTracking(url)
            ]);
        };
    }
};
function removeTracking(url) {
    if (!url) return url;
    try {
        if (typeof url === 'string') url = new URL(url, unsafeWindow.location.href);
        if (!url.search) return url;
        const keys = Array.from(url.searchParams.keys());
        for (const key of keys){
            for (const item of uselessUrlParams){
                if (typeof item === 'string') {
                    if (item === key) url.searchParams.delete(key);
                } else if ('test' in item && item.test(key)) {
                    url.searchParams.delete(key);
                }
                ;
            }
            ;
        }
        return url.href;
    } catch (e) {
        logger.error('Failed to remove useless urlParams', e);
        return url;
    }
}// 去除鸿蒙字体，强制使用系统默认字体
const useSystemFonts = {
    name: 'use-system-fonts',
    description: '去除鸿蒙字体，强制使用系统默认字体',
    any ({ addStyle }) {
        document.querySelectorAll('link[href*="/jinkela/long/font/"]').forEach((x)=>x.remove());
        addStyle(e`html, body { font-family: initial !important; }`);
    }
};const disableAV1 = {
    name: 'disable-av1',
    description: '防止叔叔用 AV1 格式燃烧你的 CPU 并省下棺材钱',
    any () {
        ((origCanPlayType)=>{
            // eslint-disable-next-line sukka/class-prototype -- override native method
            HTMLMediaElement.prototype.canPlayType = function(type) {
                if (type.includes('av01')) {
                    logger.info('AV1 disabled!', {
                        meta: 'HTMLVideoElement.prototype.canPlayType'
                    });
                    return '';
                }
                return origCanPlayType.call(this, type);
            };
        // eslint-disable-next-line @typescript-eslint/unbound-method -- override native method
        })(HTMLMediaElement.prototype.canPlayType);
        ((origIsTypeSupported)=>{
            // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- can be nullable
            if (origIsTypeSupported == null) return false;
            unsafeWindow.MediaSource.isTypeSupported = function(type) {
                if (type.includes('av01')) {
                    logger.info('AV1 disabled!', {
                        meta: 'MediaSource.isTypeSupported'
                    });
                    return false;
                }
                return origIsTypeSupported.call(this, type);
            };
        // eslint-disable-next-line @typescript-eslint/unbound-method -- override native method
        })(unsafeWindow.MediaSource.isTypeSupported);
    }
};((unsafeWindow1)=>{
    const modules = [
        defuseSpyware,
        disableAV1,
        enhanceLive,
        fixCopyInCV,
        noAd,
        noP2P,
        noWebRTC,
        optimizeHomepage,
        optimizeStory,
        playerVideoFit,
        removeBlackBackdropFilter,
        removeUselessUrlParams,
        useSystemFonts
    ];
    const styles = [];
    const onBeforeFetchHooks = new Set();
    const onResponseHooks = new Set();
    const onXhrOpenHooks = new Set();
    const onAfterXhrOpenHooks = new Set();
    const fnWs = new WeakSet();
    function onlyCallOnce(fn) {
        if (fnWs.has(fn)) {
            return;
        }
        fnWs.add(fn);
        fn();
    }
    const hook = {
        addStyle (style) {
            styles.push(style);
        },
        onBeforeFetch (cb) {
            onBeforeFetchHooks.add(cb);
        },
        onResponse (cb) {
            onResponseHooks.add(cb);
        },
        onXhrOpen (cb) {
            onXhrOpenHooks.add(cb);
        },
        onAfterXhrOpen (cb) {
            onAfterXhrOpenHooks.add(cb);
        },
        onlyCallOnce
    };
    const hostname = unsafeWindow1.location.hostname;
    const pathname = unsafeWindow1.location.pathname;
    for (const module of modules){
        if (module.any) {
            logger.log(`[${module.name}] "any" ${unsafeWindow1.location.href}`);
            module.any(hook);
        }
        switch(hostname){
            case 'www.bilibili.com':
                {
                    if (pathname.startsWith('/read/cv')) {
                        if (module.onCV) {
                            logger.log(`[${module.name}] "onCV" ${unsafeWindow1.location.href}`);
                            module.onCV(hook);
                        }
                    } else if (pathname.startsWith('/video/')) {
                        if (module.onVideo) {
                            logger.log(`[${module.name}] "onVideo" ${unsafeWindow1.location.href}`);
                            module.onVideo(hook);
                        }
                        if (module.onVideoOrBangumi) {
                            logger.log(`[${module.name}] "onVideoOrBangumi" ${unsafeWindow1.location.href}`);
                            module.onVideoOrBangumi(hook);
                        }
                    } else if (pathname.startsWith('/bangumi/play/')) {
                        if (module.onVideo) {
                            logger.log(`[${module.name}] "onVideo" ${unsafeWindow1.location.href}`);
                            module.onVideo(hook);
                        }
                        if (module.onBangumi) {
                            logger.log(`[${module.name}] "onBangumi" ${unsafeWindow1.location.href}`);
                            module.onBangumi(hook);
                        }
                        if (module.onVideoOrBangumi) {
                            logger.log(`[${module.name}] "onVideoOrBangumi" ${unsafeWindow1.location.href}`);
                            module.onVideoOrBangumi(hook);
                        }
                    }
                    break;
                }
            case 'live.bilibili.com':
                {
                    if (module.onLive) {
                        logger.log(`[${module.name}] "onLive" ${unsafeWindow1.location.href}`);
                        module.onLive(hook);
                    }
                    break;
                }
            case 't.bilibili.com':
                {
                    if (module.onStory) {
                        logger.log(`[${module.name}] "onStory" ${unsafeWindow1.location.href}`);
                        module.onStory(hook);
                    }
                    break;
                }
        }
    }
    // Add Style
    onDOMContentLoaded(()=>{
        const head = document.head || document.getElementsByTagName('head')[0];
        const style = document.createElement('style');
        style.setAttribute('type', 'text/css');
        style.textContent = styles.join('\n');
        head.appendChild(style);
    });
    // Override fetch
    (($fetch)=>{
        unsafeWindow1.fetch = function(...$fetchArgs) {
            let abortFetch = false;
            let fetchArgs = $fetchArgs;
            let mockResponse = null;
            for (const obBeforeFetch of onBeforeFetchHooks){
                try {
                    fetchArgs = obBeforeFetch($fetchArgs);
                    if (fetchArgs === null) {
                        abortFetch = true;
                        break;
                    } else if ('body' in fetchArgs) {
                        abortFetch = true;
                        mockResponse = fetchArgs;
                        break;
                    }
                } catch (e) {
                    logger.error('Failed to replace fetcherArgs', e, {
                        fetchArgs: $fetchArgs
                    });
                }
            }
            if (abortFetch) {
                logger.info('Fetch aborted', {
                    fetchArgs: $fetchArgs,
                    mockResponse
                });
                return Promise.resolve(mockResponse ?? new Response());
            }
            return Reflect.apply($fetch, this, $fetchArgs).then((response)=>{
                for (const onResponse of onResponseHooks){
                    response = onResponse(response);
                }
                return response;
            });
        };
    })(unsafeWindow1.fetch);
    (function(open) {
        unsafeWindow1.XMLHttpRequest.prototype.open = function(...$args) {
            let xhrArgs = $args;
            for (const onXhrOpen of onXhrOpenHooks){
                try {
                    xhrArgs = onXhrOpen($args, this);
                    if (xhrArgs === null) {
                        break;
                    }
                } catch (e) {
                    logger.error('Failed to replace P2P for XMLHttpRequest.prototype.open', e);
                }
            }
            if (xhrArgs === null) {
                logger.info('XHR aborted', {
                    $args
                });
                this.send = o;
                this.setRequestHeader = o;
                return;
            }
            Reflect.apply(open, this, xhrArgs);
            for (const onAfterXhrOpen of onAfterXhrOpenHooks){
                try {
                    onAfterXhrOpen(this);
                } catch (e) {
                    logger.error('Failed to call onAfterXhrOpen', e);
                }
            }
        };
    // eslint-disable-next-line @typescript-eslint/unbound-method -- called with Reflect.apply
    })(unsafeWindow1.XMLHttpRequest.prototype.open);
})(unsafeWindow);})();