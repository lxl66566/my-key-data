// ==UserScript==
// @name        Auto hide liked twitter
// @namespace   Violentmonkey Scripts
// @match        https://twitter.com/*
// @match        https://mobile.twitter.com/*
// @match        https://x.com/*
// @grant       none
// @version     1.0
// @author      -
// @description 2/9/2025, 10:08:58 PM
// ==/UserScript==


(function() {
    'use strict';

    function hideLikedTweets() {
        // Find all like buttons.  Twitter uses different selectors, so we need to cover them.
        document.querySelectorAll(
            'button[data-testid="unlike"]'
        ).forEach(button => {
            // Check if it's an "unlike" button (meaning it's already liked)
            if (button.getAttribute('data-testid') === 'unlike' || button.querySelector('div[data-testid="unlike"]')) {

                // Find the tweet container and hide it.
                let tweetContainer = button.closest('article[data-testid="tweet"]');
                if (tweetContainer) {
                    tweetContainer.style.display = 'none'; // Hide the entire tweet
                }
            }
        });
    }
      function showSensitiveContent() {
        // Find *all* span elements on the page.
        const spans = document.querySelectorAll('span');

        spans.forEach(span => {
            // Check if the innerText is exactly "Show".  Use trim() to handle whitespace.
            if (span.innerText.trim() === 'Show') {
                // Find the closest ancestor button element.
                const button = span.closest('button');

                // If a button is found, click it.
                if (button) {
                    button.click();
                }
            }
        });
    }

   function runAll() {
      // Get the current URL path.
      const path = window.location.pathname;

      // Check if the path matches your profile's "Likes" page.
      if (path.endsWith('/likes')) {
          return; // Exit the function, don't run the script.
      }

        hideLikedTweets();
     showSensitiveContent();
    }

    // Run initially on page load
    runAll();

    // Observe changes to the DOM
    const observer = new MutationObserver(runAll);
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
})();
